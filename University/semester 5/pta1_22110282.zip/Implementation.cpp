#include <iostream>
#include <string>
#include <vector>
#include "QueueStack.cpp"
using namespace std;
struct User{
	string name;
	string tweet;
	int region;

	User(){
		name = "";
		tweet = "";
		region = 0 ;
	}
	User(string s, string t, int r){
		name = s;
		tweet = t;
		region = r;
	}

};


class Twitter{
public:
	// two seperate regions maintained by the twitter server
	Queue<User> region1 ;
	Queue<User> region2 ;

	// record of the latest tweets
	Queue<User> record ;

	// constants for region 1 and 2
	const int RONE = 1 ;
	const int RTWO = 2 ;
	// sum of users from region 1 and region 2
	int total_users ;

	// combined capacity of the two regions i.e if region 1 has 12 users and region 2 has 5 users, then capacity = 17
	int capacity;

	Twitter(){

	}
	// utility function provided, returns true if s2 is substring of s1
	bool isSubString(string s1, string s2){
		size_t found = s1.find(s2);
		if(found == string::npos){
			return false;
		}
		return true;
	}

	// return names of users present in the records in the order of latest to earliest tweets
	vector<string> UsersNames(){


	    cout << "names -->";
        cout << Queue.dequeue();
        ListItem<T> *temp = Queue.dequeue();

        for (int i = 0; i < capacity; i--)
            {
            if (i == 0) cout << "\t";
            else cout << "\t\t";
            cout << temp->value;
            temp = temp->prev;
            if (i != capacity - 1)
            cout << endl;
            }

	}
	// load user to the twitter based on region, return true if joining was successful, false otherwise
	bool loadUser(string name, string tweet, int region){

	}


	// serve the users and allow them to post based on rules given in handout
	// start with region 1
	void processPosts(){

	}

	// return vector of last n name of users whose tweets may contain hate speech and remove their data from record
	// remaining record order should not change
	// words is a vector containing possible hate words based on which you will flter and remove data
	// if a tweet contains even one word from 'words', you will delete that users data
	// strictly use stack and queue functions only, you are allowed to make one temp stack/queue if you wish
	vector<string> deleteHateSpeech(vector<string> words,int n){

	}
	// return number of total users on twitter
	int noOfUsers(){}

};

