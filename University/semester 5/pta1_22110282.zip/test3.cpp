#include <iostream>
#include <vector>
#include <string>
#include "implementation.cpp"
using namespace std;

int main(){

	Twitter server1 ;
	vector<string> possible_hate_words {"Ugly", "Violence" , "Fat" , "Disgusting" , "Die" , "Hate" , "Kill"} ;
	vector<string> latest_users ;
	vector<string> possible_haters;
	vector<string> names {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
	vector<string> tweets {"I Will Kill You",
						   "I love you",
						   "I Am Travelling",
						   "You Are Disgusting",
						   "Football Is Good",
						   "Fine",
						   "Great",
						   "Hey How Are You",
						   "I Think You Are Fat",
						   "Jk You Are Ugly",
						   "Hate Yourself",
						   "Lol Funny",
						   "I love Violence",
						   "New To Twitter",
						   "Just Die",
						   "HeLLo Boy",
						   "Awesome",
						   "Our President IS Good",
						   "I Am Sad",
						   "KFC IS THE BEST",
						   "You Are My Best Friend",
						   "Veal", "W" , "X", "Y", "Z"};

	vector<string> check_latest_users {"T","S","J","I","R","Q","H","G","P","O","F","E","N","M","D","C","L","K","B","A"};
	vector<string> check_haters {"A","K","D","M","O","I","J"};
	std::vector<string> check_remaining_record {"T","S","R","Q","H","G","P","F","E","N","C","L","B"};

	int r = 1 ;
	bool t;
	for(int i = 0 ; i<names.size();i++){
		t = server1.loadUser(names[i], tweets[i], r);
		if(i==9){r++;}
		if(i<20 && t == false){
			cout << "Test 0-1 Failed" << endl;
			return 1 ;
		}
		if(i>= 20 && t){
			cout << "Test 0-1 Failed" << endl;
			return 1 ;
		}
	}
	cout << "Test 0-1 Passed" << endl ;

	if(server1.noOfUsers() == 20){
		cout << "Test 0-2 passed" << endl ;
	}
	else{
		cout << "Loading Failed" << endl ;
		return 1;
	}
	server1.processPosts();
	latest_users = server1.UsersNames();

	if(check_latest_users == latest_users){
		cout << "Test 1 Passed" << endl ;
	}
	else{
		cout << "Loading Failed" << endl ;
		return 1;
	}

	possible_haters = server1.deleteHateSpeech(possible_hate_words,20);
	if(possible_haters == check_haters){
		cout << "Test 2 Passed" << endl ;
	}
	else{
		cout << "Deletion Failed" << endl ;
		return 1;
	}

	latest_users = server1.UsersNames();
	if(check_remaining_record == latest_users && server1.noOfUsers()== 13){
		cout << "Test 3 Passed" << endl ;
	}
	else{
		cout << "Deletion Failed" << endl ;
		return 1;
	}

	cout << "All Tests Passed" << endl ;


}