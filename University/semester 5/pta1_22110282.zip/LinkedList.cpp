#ifndef __LIST_CPP
#define __LIST_CPP
#include <cstdlib>

/* linked list node struct */
template <class T>
struct ListItem
{
    T value;
    ListItem<T> *next;
    ListItem<T> *prev;

    ListItem(T theVal)
    {
        this->value = theVal;
        this->next = NULL;
        this->prev = NULL;
    }
};

/* This is the generic List class */
template <class T>
class LinkedList
{
    ListItem<T> *head;
    ListItem<T> *tail;

public:
    // Constructor
    LinkedList();
    // Copy Constructor
    // Deep cpopy
    LinkedList(const LinkedList<T>& otherList);
    // Destructor
    // properly free every node, just setting head and tail to NULL will be given 0.
    ~LinkedList();
    // Insertion Functions
    void insertAtHead(T item);
    void insertAtTail(T item);
    void insertAfter(T toInsert, T afterWhat);
    // getters
    ListItem<T> *getHead();
    ListItem<T> *getTail();
    ListItem<T> *searchFor(T item);
    // Deletion
    // Delete only the 1st instance of an element ;
    void deleteElement(T item);
    void deleteHead();
    void deleteTail();
    // extras
    int length();
    // reverse the linked list
    void flip();
};

template <class T>
LinkedList<T>::LinkedList()
{
  head = NULL;
  tail = NULL;
}






template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& otherLinkedList)
{
    int count =0;

		if (otherLinkedList.head == NULL)
		{
			head = NULL;
			tail = NULL;
			count = 0;
		}

        else
        {
            ListItem<T>* current = otherLinkedList.head;
            head = NULL;
            tail = NULL;

            while(current!=NULL)
            {

              ListItem<T> *newNode = new ListItem<T>(current->value);

              newNode->prev=NULL;
              newNode->next=NULL;
              newNode->value=current->value;


                  if(count == 0)
                    {
                        head = newNode;
                        tail = newNode;
                    }
                  else
                    {
                        tail->next= newNode;
                        newNode->prev=tail;
                        tail = tail->next;
                    }

                  ++count;
                  current = current->next;

                }
            }

}








template <class T>
LinkedList<T>::~LinkedList()
{

     ListItem<T> *temp = NULL;
    while(head)
    {
        temp = head;
        head = head->next;
        delete temp;
    }

      head = NULL;
}






template <class T>
void LinkedList<T>::insertAtHead(T item)
{

    ListItem<T> *temp = new ListItem<T>(item);

    if (head==NULL)
    {
        tail = head;
    }
    else
    {

        temp->next = head;

        head = temp;
    }


}




template <class T>
void LinkedList<T>::insertAtTail(T item)
{
   /* Node *node = new Node(val);
    {
        tail->next = node;
        tail = node;

        p ka agla null nahi to age karte jana he
    }*/

    if (head == NULL)
    {
        head = new ListItem<T> (item);
        tail = head;
    }
    else
    {
        ListItem<T> *temp = new ListItem<T>(item);
        tail->next = temp;
        tail= temp;
    }

}




template <class T>
void LinkedList<T>::insertAfter(T toInsert, T afterWhat)
{

    ListItem<T> *temp = new ListItem<T>(toInsert);
    ListItem<T> *temp1 = head;

    while(temp1->value != afterWhat && temp1!= NULL)
        {
            temp1 = temp1->next;
        }
    temp->next = temp1->next;
    temp->prev = temp1;

    if (temp1->next != NULL)
        temp1->next->prev = temp;
    else
        tail = temp;
    temp1->next = temp;
}



template <class T>
ListItem<T>* LinkedList<T>::getHead()
{
    return head;

}

template <class T>
ListItem<T>* LinkedList<T>::getTail()
{
    return tail;
}



template <class T>
ListItem<T> *LinkedList<T>::searchFor(T item)
{
     ListItem<T> *here = head;
     ListItem<T> te = ListItem<T>(item);
     if (here == NULL)
     {
         return NULL;
     }
     else
     {
         while (here->value!= item && here->next != NULL)
        {
            here = here->next;
        }

     }

     if (here->value == item)
        return here;
     else
        return NULL;
}








template <class T>
void LinkedList<T>::deleteElement(T item)
{
    if(head!= NULL)
    {
        ListItem<T> *temp1 = head;
        ListItem<T> *old_temp = temp1;

        while(temp1!= NULL && temp1->value != item) // go to the given node
        {
            old_temp = temp1; 	// transfer the address of 'temp1' to 'old_temp'
 	        temp1 = temp1->next; 	// transfer the address of 'temp1->next' to 'temp1�

        }

        old_temp->next = temp1->next;
        temp1->next->prev = old_temp;
        delete temp1;
    }


}

template <class T>
void LinkedList<T>::deleteHead()
{
    /*
    if head!= null:
        temp = head; // transfer the address of 'head' to 'temp'
head = temp->next; // transfer the address of 'temp->next' to 'head'
delete temp;
*/
    if(head!= NULL)
    {
        ListItem<T> *temp = head;

        head = temp->next;
        head->prev = NULL;
        delete temp;

    }
}

template <class T>
void LinkedList<T>::deleteTail()
{
    /*temp1 = head;
old_temp = temp1;
while(temp1->next != NULL) 	// go to the last node
 {
 	old_temp = temp1; 	// transfer the address of 'temp1' to 'old_temp'
 	temp1 = temp1->next; 	// transfer the address of 'temp1->next' to 'temp1�
}
 old_temp->next = NULL; 		// next node of the last node is null
 delete temp1;

*/

    if(head!= NULL)
        {
            ListItem<T> *temp1 = head;
            ListItem<T> *old_temp = temp1;

            if(head->next== NULL)
            {
                /*ListItem<T> *temp1 = head;
                  ListItem<T> *old_temp = temp1;*/
                delete head;
                head = NULL;
                tail = NULL;
            }

            else
            {
                while(temp1->next!= NULL)
                {
                    old_temp = temp1;
                    temp1 = temp1->next;
                }

                tail = old_temp;
                old_temp->next = NULL;
                delete temp1;
            }
        }

}

template <class T>
int LinkedList<T>::length()
{

    //count =0;
    /*while(head!=0)
    {temp = temp->next
    count++}
    return count;*/

    ListItem<T> *temp = head;
    int counte = 0;
    if (head==NULL)
    {
        counte = 0;
        return counte;
    }

    else if(head->next == NULL)
    {
        counte = 1;
        return counte;

    }
    else
    {
        while(temp!= NULL)
        {
            counte++;
            temp = temp->next;
        }
        return counte;

    }


}

template <class T>
void LinkedList<T>::flip()
{
    if (head!= NULL)
    {
        ListItem<T> *current;
        ListItem<T> *temp;
        current = head;



    while(current!= NULL)
    {
        temp = current->next;
        current->next = current->prev;
        current->prev = temp;
        current = temp;
    }


    temp = head;
    head = tail;
    tail = temp;



    }


}

#endif
