#ifndef __QUEUESTACK_CPP
#define __QUEUESTACK_CPP
#include "LinkedList.cpp"


/* This is the generic Queue class */
template <class T>
class Queue
{
    LinkedList<T> list;

  public:

    // Constructor
    Queue();
    // Required Methods
    void enqueue(T item);
    T front();
    T dequeue();
    int length();
    // return true if empty, false if non empty
    bool isEmpty();
};

template <class T>
Queue<T>::Queue()
{
    /*head = NULL;
    tail = NULL;
    */

    //list.getHead();
    //list.getTail();
}

template <class T>
void Queue<T>::enqueue(T item)
{
    list.insertAtTail(item);

}

template <class T>
T Queue<T>::front()
{
    if (!isEmpty())
    {
        T temp;
        temp = list.getHead()->value;
        return temp;
    }


}

template <class T>
T Queue<T>::dequeue()
{

    T temp = list.getHead()->value;
    list.deleteHead();
    return temp;


}

template <class T>
int Queue<T>::length()
{

    return list.length();
}

template <class T>
bool Queue<T>::isEmpty()
{
    if(list.length() == 0)
    {
        return true;
    }

    else
        return false;

}






template <class T>
class Stack
{
    LinkedList<T> list;

  public:

    // Constructor
    Stack();
    // Required Methods
    void push(T item);
    T top();
    T pop();
    int length();
    bool isEmpty();
};

template <class T>
Stack<T>::Stack(){
    list.getHead();
    list.getTail();}


template <class T>
void Stack<T>::push(T item)
{
    list.insertAtHead(item);
}

template <class T>
T Stack<T>::top()
{

    if (!isEmpty())
    {
        return list.getHead()->value;
    }
}

template <class T>
T Stack<T>::pop()
{
    if (!isEmpty())
    {
        T temp = list.getHead()->value;
        list.deleteHead();
        return temp;
    }

}

template <class T>
int Stack<T>::length()
{
    return list.length();

}

template <class T>
bool Stack<T>::isEmpty(){

    if (list.getHead() == NULL)
    return true;
    else
        return false;

}

#endif

