#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>
using namespace std;

int counter=0;
class Game
{
	string p1;
	string p2;
	char s1;
	char s2;
	int cap;
	char **b;
	
public:
	Game()
	{
		cap = 3;
		p1 = "Player 1";
		p2 = "Player 2";
		s1 = 'x';
		s2 = 'o';
		b = new char *[cap];
	    for(int i=0; i<cap; i++)
	    {
	        b[i] = new char [cap];
	    }
	}
	
	Game(string pl1 , string pl2 , char sy1 , char sy2)
	{
		cap = 3;
		p1 = pl1;
		p2 = pl2;
		s1 = sy1;
		s2 = sy2; 
		b = new char *[cap];
	    for(int i=0; i<cap; i++)
	    {
	        b[i] = new char [cap];
	    }
	}


	~ Game()
	{
		for(int j=0; j<cap; j++)
	    {
	        delete [] b[j];
	    }
	    delete [] b;
	}
	
	
	Game( Game& obj)
	{
		p1= obj.p1;
		p2 = obj.p2;
		s1 = obj.s1;
		s2 = obj.s2;
		cap =3;
		b = new char *[cap];
	    for(int i=0; i<cap; i++)
	    {
	        b[i] = new char [cap];
	    }
		for(int i=0; i<cap; i++)
	    {
	        for(int j=0; j<cap; j++)
	        {
	            b[i][j] =obj.b[i][j];
	        }
		}
	}
	
	
	
	void printBoard()
	{
		resetBoard();
		while(!checkWinner())
		{
			system("pause");
			system("cls");
			cout << endl;
			cout << "You can use any symbol except space bar.";
			cout<< "\nPlayer " << p1 << ": "<< s1<<endl;
			cout<< "Player " << p2 << ": "<< s2<<endl << endl;
			cout << "Choose box between 1 to "<< cap*cap<<endl;
			cout <<"_____________"  << endl  << endl;
				for(int i=0; i<cap; i++)
		    {
		    	cout << "| ";
		        for(int j=0; j<cap; j++)
		        {
					cout << b[i][j] << " | ";
		        }
		        cout <<endl<<"_____________"  << endl  << endl;
		    }	
		    toggleplayer();
			playerMove(); 
		}
			system("cls");
		if (checkWinner())
		{
			
			cout <<"_____________"  << endl  << endl;
				for(int i=0; i<cap; i++)
		    {
		    	cout << "| ";
		        for(int j=0; j<cap; j++)
		        {
					cout << b[i][j] << " | ";
		        }
		        cout <<endl<<"_____________"  << endl  << endl;
		    }	
				
		}
		
	}
	
	
	void toggleplayer()
	{
		if (counter%2 == 0)
		{
			cout << p1 << "'s move: ";
			counter++;
		}
		else 
		{
			cout << p2 << "'s move: ";
			counter++;
		}
	}
	
	
	
	int takeinput()
	{
		int i;
		cin>> i;
		return i;
		
	}
	
	
	void playerMove() 
	{
		int m= takeinput();
		//cout << "m1: "<< m << endl;
		if (m<1 || m>(cap*cap))
		{
			m = (rand()%(cap*cap))+1;
		//cout << "m2: "<< m << endl;
			while (b[(m-1)/cap][(m-1)%cap]!=' ')
			{
				m = (rand()%(cap*cap))+1;
		//	cout << "m3: "<< m << endl;
			}
		}
		while (b[(m-1)/cap][(m-1)%cap]!= ' ')
		{
			cout << "Cell is not empty. Input another cell. \n";
			m= takeinput();
			if (m<1 || m>(cap*cap))
		{
			m = (rand()%(cap*cap))+1;
		//cout << "m2: "<< m << endl;
			while (b[(m-1)/cap][(m-1)%cap]!=' ')
			{
				m = (rand()%(cap*cap))+1;
		//	cout << "m3: "<< m << endl;
			}
		}
			//cout << "m4: "<< m << endl;
		}
		
		int r=(m-1)/cap;
		int c=(m-1)%cap;
	//	cout << "r: "<< r << endl;
			//cout << "c: "<< c << endl;
		if (counter%2 == 0)
		{
			b[r][c] = s2;
			//cout << "b[r][c]" << b[r][c] << endl;
		}
		else
		{
			b[r][c] = s1;
			//cout << "b[r][c]  2 : " << b[r][c] << endl;
		}
	}
	 
	 
	void resetBoard()
	 {
	 	/*b = new char *[cap];
	    for(int i=0; i<cap; i++)
	    {
	        b[i] = new char [cap];
	    }*/
		for(int i=0; i<cap; i++)
	    {
	        for(int j=0; j<cap; j++)
	        {
	            b[i][j] =' ';
	        }
		}
	 }
	 
	 bool checkWinner()
	 {
	 	bool w=0;
		 //if b[i][j same];
		bool c=0;
		/*for(int i=0; i<cap; i++)
	    {
	        for(int j=0; j<cap-1; j++)
	        {
	           if (b[i][j]!=b[i][j+1] || b[i][j]==' ' || b[i][j+1]==' ' )
	           {
	           	c=1;
	           	break;
			   }
			   if (b[j][i]!=b[j+1][i] || b[j][i]==' ' || b[j+1][i]==' ')
	           {
	           	c=1;
	           	break;
			   }
	        }
	        if (c==0)
	        {
	        	w=1;
	        	if (counter%2 == 0)
				{
					cout << p2 << " has won.\n";
				}
				else
				{
					cout << p1 << " has won.\n";
				}
			}
		}
		
		
		for(int i =0;i<cap ; i++)
		{
			if (b[i][i]!=b[i+1][i+1] || b[i][i]==' ' || b[i+1][i+1]==' ')
	           {
	           	c=1;
				break;
			   }
			   if (b[cap-1-i][i]!=b[cap-i-2][i+1] || b[cap-1-i][i]==' ' || b[cap-i-2][i+1]==' ') 
	           {
	           	c=1;
				break;
				}
				if (c==0)
	        {
	        	w=1;
	        	if (counter%2 == 0)
				{
					cout << p2 << " has won.\n";
				}
				else
				{
					cout << p1 << " has won.\n";
				}
			}
				
		}*/
		if (b[0][0]==b[0][1] && b[0][0]==b[0][2] && b[0][0]!=' ')
		{
			c=1;
		}
		else if (b[1][0]==b[1][1] && b[1][0]==b[1][2] && b[1][0]!=' ')
		{
			c=1;
		}
		else if (b[2][0]==b[2][1] && b[2][0]==b[2][2]&& b[2][0]!=' ')
				{
			c=1;
	
		}
		else if (b[0][0]==b[1][0] && b[0][0]==b[2][0] && b[0][0]!=' ')
				{
			c=1;
		}
		else if (b[0][1]==b[1][1] && b[0][1]==b[2][1] && b[0][1]!=' ')
				{
			c=1;
			 
		}
		else if (b[0][2]==b[1][2] && b[0][2]==b[2][2] && b[0][2]!=' ')
				{
			c=1;
			 
		}
		else if (b[0][0]==b[1][1] && b[0][0]==b[2][2] && b[0][0]!=' ')
				{
			c=1;
			 
		}
		else if (b[0][2]==b[1][1] && b[0][2]==b[2][0] && b[0][2]!=' ')
				{
			c=1;
			 
		}
		
		if (c==1)
	        {
	        	w=1;
	        	if (counter%2 == 0)
				{
					cout << p2 << " has won.\n";
				}
				else
				{
					cout << p1 << " has won.\n";
				}
			}
	//cout << "counter : "<< counter << endl;
		if (c==0 && counter>=(cap*cap))
		{
			w=1;
			cout << "Match has been drawn.\n";
			cout << "Do you want play again or not? y or n.\n";
			char p;
			cin >> p;
			if (p == 'y')
			{
				counter = 0;
				//	resetBoard();
				    printBoard();
				    
			}
			else if (p=='n')
			{
				
				for(int j=0; j<cap; j++)
			    {
			        delete [] b[j];
			    }
			    delete [] b;
			}
		}
		return w;
	 }
};

int main()
{
	//Game t;
	//t.printBoard();
	
	//cout << "Now Check the Game with Parametarized and copy constructor"<< endl;
 Game r("Hassan", "Haider" , '+' , '*');
 Game g(r) ;
 //g.Game;
 //g.resetBoard();
 g.printBoard();

return 0;	
	
}
